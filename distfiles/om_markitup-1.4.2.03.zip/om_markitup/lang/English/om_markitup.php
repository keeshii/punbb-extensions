<?php

$lang_om_markitup = array(
	'bold'			=> 'Bold',
	'italic'		=> 'Italic',
	'underline'		=> 'Underline',
	'picture'		=> 'Picture',
	'link'			=> 'Link',
	'yellow'		=> 'Yellow',
	'orange'		=> 'Orange',
	'red'			=> 'Red',
	'blue'			=> 'Blue',
	'purple'		=> 'Purple',
	'green'			=> 'Green',
	'white'			=> 'White',
	'gray'			=> 'Gray',
	'black'			=> 'Black',
	'colors'		=> 'Colors',
	'small'			=> 'Small',
	'big'			=> 'Big',
	'large'			=> 'Large',
	'size'			=> 'Size',
	'list'			=> 'List',
	'list-decimal'		=> 'Numeric list',
	'list-element'		=> 'List element',
	'smilies'		=> 'Smilies',
	'quote'			=> 'Quote',
	'code'			=> 'Code',
	'clear'			=> 'Clear',
	'Put texe here'		=> 'Put text here',

	'Signature size tag'	=> 'You can\'t use [size] tag in the signature.',

);
