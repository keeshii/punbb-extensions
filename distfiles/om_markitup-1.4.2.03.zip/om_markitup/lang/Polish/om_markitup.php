<?php

$lang_om_markitup = array(
	'bold'			=> 'Pogrubienie',
	'italic'		=> 'Kursywa',
	'underline'		=> 'Podkreślenie',
	'picture'		=> 'Obrazek',
	'link'			=> 'Hiperłącze',
	'yellow'		=> 'Żółty',
	'orange'		=> 'Pomarańczowy',
	'red'			=> 'Czerwony',
	'blue'			=> 'Niebieski',
	'purple'		=> 'Fioletowy',
	'green'			=> 'Zielony',
	'white'			=> 'Biały',
	'gray'			=> 'Szary',
	'black'			=> 'Czarny',
	'colors'		=> 'Kolory',
	'small'			=> 'Mały',
	'big'			=> 'Średni',
	'large'			=> 'Duży',
	'size'			=> 'Rozmiar',
	'list'			=> 'Lista punktowa',
	'list-decimal'		=> 'Lista numeryczna',
	'list-element'		=> 'Element listy',
	'smilies'		=> 'Emotikony',
	'quote'			=> 'Cytuj',
	'code'			=> 'Kod',
	'clear'			=> 'Czyść',
	'Put texe here'		=> 'Tutaj wpisz text',

	'Signature size tag'	=> 'W sygnaturze nie wolno stosować znacznika [size].',

);
