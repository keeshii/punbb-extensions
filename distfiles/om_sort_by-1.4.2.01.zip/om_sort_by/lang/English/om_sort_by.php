<?php

$lang_om_sort_by = array(
	'Sort alphabetical'	=> 'Alphabetical',
);
