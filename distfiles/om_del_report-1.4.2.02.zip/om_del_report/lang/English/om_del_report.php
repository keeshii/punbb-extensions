<?php

// Language definitions used in om_del_report
$lang_om_del_report = array(
	'Reports deleted'	=> 'Reports deleted.',
	'Delete selected'	=> 'Delete selected',
	'Delete read'		=> 'Delete reports'
);
