<?php

// Language definitions used in om_friends
$lang_om_friends = array(
	'Add friend'			=> 'Add to friends',
	'Remove friend'			=> 'Remove from friends',
	'User friends'			=> 'Friends',
	'I like me'			=> 'You really like yourself, do you?',
	'Already friend' 		=> 'This user is already your friend.',
	'Added to friends redirect'	=> 'User added to your friends',
	'I hate me'			=> 'You really hate yourself, do you?',
	'Not friend'			=> 'This user is not your friend.',
	'Removed from friends redirect'	=> 'User removed from your friends',

	'Search posts title'		=> 'New posts of friends',
	'Search posts'			=> 'Friends posts',

	'Friend posts'			=> 'Recent posts of friends',
);
