<?php

// Language definitions used in om_del_user
$lang_om_del_user = array(
	'Delete my profile'			=> 'Delete my profile',	// link in profile
	'Delete profile'			=> 'Delete profile',	// section name in crumbs
	'User delete redirect'			=> 'Profile has been deleted.',	// redirect flash msg
	'Delete'				=> 'Delete profile',	// button
	'Cancel'				=> 'Cancel',	// button
	'Delete warning'			=> 'Are you crazy? You are going to delete your profile. Don\'t you like us anymore?',
);
