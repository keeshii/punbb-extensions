<?php

// language pack for multi-quoting
$lang_om_multiquote = array(
	'Quote'			=> 'Toggle Quote',
);
