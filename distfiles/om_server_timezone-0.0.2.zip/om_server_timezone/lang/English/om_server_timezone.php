<?php

$lang_om_server_timezone = array(
	'Server timezone'		=>	'Use the timezone settings of the server',
); 
