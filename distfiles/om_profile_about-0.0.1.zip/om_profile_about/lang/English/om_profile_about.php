<?php

$lang_om_profile_about = array(
	'Description legend'		=>	'Additional informations',
	'Description label'		=>	'Description',
	'Current description'		=>	'Current description',

	'Description too long'		=>	'Description cannot be longer than %1$s characters. Please reduce your description by %2$s characters.',
	'Description too many lines'	=>	'Description cannot have more than %s lines.',

	'Features desc'			=>	'User descriptions and description content',
	'Features desc legend'		=>	'Description options',
	'Allow capitals group'		=>	'Allow all capitals',
	'All caps desc label'		=>	'Allow descriptions to contain only capital letters.',
	'Max desc length label'		=>	'Maximum characters',
	'Max desc lines label'		=>	'Maximum lines',
); 
