<?php

$lang_om_countdown = array(
	'Countdown settings'			=> 'Countdown settings',
	'Countdown description'			=> 'Change date the counter is pointing to.',
	'Countdown to date'			=> 'Countdown to date',
	'Countdown to date or empty'		=> 'YYYY-MM-DD hh:mm, or leave it empty',
	'Counter title'				=> 'Counter name',
	'Name of important event'		=> 'Name of an important event',
);
