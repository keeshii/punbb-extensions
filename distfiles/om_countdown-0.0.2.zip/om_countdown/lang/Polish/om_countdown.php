<?php

$lang_om_countdown = array(
	'Countdown settings'			=> 'Licznik ustawienia',
	'Countdown description'			=> 'Zmień datę, do której odliczamy.',
	'Countdown to date'			=> 'Data licznika',
	'Countdown to date or empty'		=> 'YYYY-MM-DD hh:mm, lub pozostaw puste',
	'Counter title'				=> 'Nazwa licznika',
	'Name of important event'		=> 'Nazwa ważnego wydarzenia',
);
