<?php

// Language definitions used in pun_pm
$lang_om_fill_location = array(
	'Fill your profile'	=> 'Fill your profile',
	'We are sad'		=> 'We are sad!',
	'Why are we sad'	=> 'We want to play with you, but we don\'t know where you live. Do us a favor, and fill your profile. It would be easier to find you ^_^',
	'Continue to forum'	=> 'Continue to forum',
);

?>
