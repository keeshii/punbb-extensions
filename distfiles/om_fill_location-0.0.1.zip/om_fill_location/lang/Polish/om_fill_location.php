<?php

// Language definitions used in pun_pm
$lang_om_fill_location = array(
	'Fill your profile'	=> 'Uzupełnij swój profil',
	'We are sad'		=> 'Smutno nam!',
	'Why are we sad'	=> 'Chętnie byśmy z tobą pograli, ale nie wiemy gdzie mieszkasz. Proszę zrób nam przysługę, uzupełnij swój profil. Wtedy łatwiej Cię znajdziemy ^_^',
	'Continue to forum'	=> 'Przejdź do forum',
);

?>
