<?php
/**
 * Default SEF URL scheme.
 *
 * @copyright (C) 2013 PunBB
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package om_fill_location
 */

$forum_url['om_fill_location'] = 'misc.php?section=om_fill_location';

?>