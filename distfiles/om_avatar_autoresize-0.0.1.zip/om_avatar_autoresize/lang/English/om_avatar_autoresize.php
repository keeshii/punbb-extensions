<?php

// Language definitions used in om_avatar_autoresize
$lang_om_avatar_autoresize = array(
	// forum settings
	'Autoresize settings'			=>	'Autoresize settings',
	'Keep aspect ratio'			=>	'Keep aspect ratio',
	'Users can disable scalling'		=>	'Users can disable scalling',
	'Scale avatars by default'		=>	'Scale avatars by default',

	// profile - avatars
	'Scale avatar'				=> 	'Scale avatar',
	'Scale avatar info'			=> 	'Scale the avatar to the desired size',
);
