<?php

// Language definitions used in om_thanks
$lang_om_thanks = array(
	'Give thanks'			=> 'Dzięki',
	'Take thanks'			=> 'Nie dziękuj',
	'Thanks added'			=> 'Podziękowanie dodane',
	'Thanks taken'			=> 'Podziękowanie wycofane',

	'Thankers'			=> 'Podziękowali za posta',
	'and more'			=> '(%s więcej)',


	'Thanks settings'		=> 'Ustawienia do podziękowań',
	'Features title'		=> 'Ustawienia',
	'Max thanks'			=> 'Max. podziękowań na post',
	'Max thanks info'		=> '0 - brak limitu, zalecane 50',

	'Additional options'		=> 'Dodatkowe ustawienia',
	'Show profile'			=> 'Pokaż liczbę podziękowań w profilu',
	'Show post'			=> 'Pokaż listę dziękujących pod sygnaturą',
	'Allow take'			=> 'Pozwól na wycofanie podziękowań',

	'Thanks count'			=> 'Podziękowań',
	'View user thanks'		=> 'Zobacz wszystkie posty z podziękowaniami użytkownika %s',

	'Thanks by'			=> 'Posty od %s z podziękowaniami',
);
