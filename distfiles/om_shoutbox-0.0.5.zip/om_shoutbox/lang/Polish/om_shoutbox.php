<?php

$lang_om_shoutbox = array(
	'Loading'		=> 'Wczytywanie listy wiadomości...',
	'Send'			=> 'Wyślij',

	'Shoutbox color'	=> 'Kolor w shoutboxie',
	'Random color'		=> '(Wybierz za mnie)',
	
	'Features title'	=> 'Shoutbox',
	'Shoutbox settings'	=> 'Shoutbox ustawienia',
	'Setup colors'		=> 'Lista kolorów',
	'Setup colors info'	=> 'W poniższym polu możesz określać kolory, które użytkownicy będą mogli wybrać w opcjach shoutboxa. Muszą być one zgodne z kodami HTML, oddzielone spacjami lub nową linią.',
	'Message length'	=> 'Max. długość wiadomości',
	'Message length info'	=> 'zalecane 512, max 2048',
	'Message time'		=> 'Czas wyświetlania wiadomości',
	'Message time info'	=> '[min] zalecane 60',
	'Message count'		=> 'Max. liczba wiadomości',
	'Message count info'	=> 'zalecane 50',
	'Refresh rate'		=> 'Częstotliwość odświeżania [ms]',
	'Refresh rate info'	=> '[ms] zalecane 3000, min. 500',
	'Display options'	=> 'Opcje wyświetlania',
	'Show on top'		=> 'Shoutbox będzie pokazywany na górze strony',
	'Show to guests'	=> 'Wyświetlaj shoutbox gościom (niezalecane)',
	'Show smilies'		=> 'Dekoduj uśmieszki w wiadomościach',

	'Block shoutbox'	=> 'Blokuj shoutbox',
);