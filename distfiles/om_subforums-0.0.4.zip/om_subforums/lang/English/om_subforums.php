<?php

// Language definitions used in subforums
$lang_om_subforums = array(
	'Set parent forum label'	=> 'Set parent forum',
	'Without parent'		=> '(Without parent)',
	'Sections'			=> 'Sections: ',
	'Subforums'			=> 'Subforums',
	'Show mode label'		=> 'Show subforums mode',
	'Show on index'			=> 'Show subforums on index page',
	'Show in topics'		=> 'Show subforums in the list of topics',
	'Show both'			=> 'Show both',
	'---'				=> ' - - - ',
);

