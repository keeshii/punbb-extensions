<?php

// Language definitions used in subforums
$lang_om_subforums = array(
	'Set parent forum label'	=> 'Forum nadrzędne',
	'Without parent'		=> '(brak rodzica)',
	'Sections'			=> 'Działy: ',
	'Subforums'			=> 'Lista działów',
	'Show mode label'		=> 'Tryb wyświetlania działów',
	'Show on index'			=> 'Pokaż na stronie głównej',
	'Show in topics'		=> 'Pokaż razem z tematami',
	'Show both'			=> 'Pokaż tu i tam',
	'---'				=> ' - - - ',
);

